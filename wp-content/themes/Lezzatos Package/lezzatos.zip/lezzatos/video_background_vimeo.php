<?php
/**
* Template Name: Video background Vimeo
*
*/
?> 
<?php get_header(); ?>
<?php get_footer(); ?>